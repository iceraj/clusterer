package com.bugaco.mioritic.impl.misc;

/**
 * <p>Title: Mioritic</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: bugaco</p>
 *
 * @author Ivica Ceraj
 * @version 1.0
 */
public class ProgressModel extends com.bugaco.ui.models.impl.DefaultProgressModel implements com.bugaco.mioritic.model.misc.ProgressModel {
    public ProgressModel() {
    }
}
